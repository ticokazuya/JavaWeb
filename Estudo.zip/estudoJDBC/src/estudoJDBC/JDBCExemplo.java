package estudoJDBC;
import java.sql.*;

public class JDBCExemplo {

	public static void main(String[] args) throws SQLException {
		Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost/fj21");
		System.out.println("conectado!");
		conexao.close();
	}

}

public class ConnectionFactory {
	public Connection getConnection() {
		try{
			return DriverManager.getConnection("jdbc:mysql://localhost/fj21","root","<SENHA DO BANCO AQUI>");
		}catch(SQLException e) {throw new RuntimeException(e);
		}
	}
}
//como adicionar driver do MySQL ao classpath
//	adicionar	o	driver	do	MySQL	ao	classpath,	ou	seja,	o	arquivo	.jar	contendo
//a	implementa��o	JDBC	do	MySQL	(mysql	connector)	precisa	ser	colocado	em	um	lugar	vis�vel	pelo	seu
//projeto	 ou	 adicionado	 �	 vari�vel	 de	 ambiente	 	CLASSPATH	
//adicionando
//faremos	isso	 atrav�s	 de	 um	 clique	 da
//direita	em	nosso	projeto,	Build	Path	e	em	Add	to	Build	Path.	