package estudoBD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;



public class Laboratorio {

	public static void main(String[] args) Throws SQLException {
		Connection con = DriverManager.getConnection("jdbc:derby:d:\\temp\\BDTeste");//criando conex�o
		
		System.out.println("Conex�o criada.");
		
		Scanner scan = new Scanner(System.in);//scaner
		
		PreparedStatement pstmt = con.prepareStatement("Insert into tabela(nome) values(?)");
		//aceita passagem de parametro.
		
		System.out.println("Entre com o nome.");
		pstmt.setString(1, scan.nextLine());
		pstmt.executeUpdate();
		
		Statemant stmt = con.createStatemant();
		//m�todos para executar uma insstru��o. Essa n�o aceita passagem de parametro.
		ResultSet rs = stmt.execulteQuery("elect id, nome fron tabela");
		//permite o recebimento e gerenciamento do ci=onjunto de dados retornados pela consulta
		//SQL e � armazenado como uma lista.
		
		while(rs.next()) {
			System.out.println("Nome = " + rs.getString("nome"));
		}
		rs.close();
		stmt.close();
		scan.close();
		pstmt.close();
		con.close();
	}
}
